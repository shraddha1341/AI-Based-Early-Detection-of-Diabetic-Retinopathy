"""
dataset.py
----------
Loads the retinal images + labels and prepares them for training.

Handles two of the four things the assignment asks you to address:

1. IMAGE QUALITY
   Before training, every image is checked with a simple blur detector
   (variance of the Laplacian -- a standard, lightweight OpenCV/skimage
   technique). Images that are too blurry to be useful are dropped, the
   same way a real screening pipeline would flag "recapture this photo"
   instead of trying to diagnose off a bad image.

2. CLASS IMBALANCE
   get_weighted_sampler() computes a sampling weight per image, inversely
   proportional to how common its class is. This makes the model see
   rare classes (Severe / Proliferative DR) roughly as often as common
   ones (No DR) during training, instead of learning to just always
   predict "No DR".

If you switch to the real APTOS dataset, nothing else in this file needs
to change -- just set USE_REAL_DATA = True and make sure data/train.csv
has columns id_code, diagnosis (and optionally "group" if you have a
demographic attribute to evaluate fairness on; if not, that check is
simply skipped).
"""

import os
import pandas as pd
import numpy as np
from PIL import Image
from skimage.filters import laplace
import torch
from torch.utils.data import Dataset, WeightedRandomSampler
from torchvision import transforms

USE_REAL_DATA = False  # flip to True once you drop in the real APTOS folder

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
IMG_DIR = os.path.join(DATA_DIR, "train")
CSV_PATH = os.path.join(DATA_DIR, "train.csv")

CLASS_NAMES = ["No_DR", "Mild", "Moderate", "Severe", "Proliferative_DR"]

BLUR_VARIANCE_THRESHOLD = 15.0  # below this -> image treated as too blurry to use


def blur_score(img: Image.Image) -> float:
    """Higher = sharper. Classic Laplacian-variance blur detector."""
    gray = np.array(img.convert("L"), dtype=np.float64)
    return float(laplace(gray).var())


def load_and_filter_labels() -> pd.DataFrame:
    """Reads the label CSV and drops rows whose image is too blurry to use.
    This is the 'image quality' handling step."""
    df = pd.read_csv(CSV_PATH)
    keep_rows = []
    dropped = 0
    for _, row in df.iterrows():
        img_path = os.path.join(IMG_DIR, row["id_code"])
        try:
            with Image.open(img_path) as img:
                score = blur_score(img)
        except Exception:
            dropped += 1
            continue
        if score < BLUR_VARIANCE_THRESHOLD:
            dropped += 1
            continue
        keep_rows.append(row)

    filtered = pd.DataFrame(keep_rows).reset_index(drop=True)
    print(f"[quality filter] kept {len(filtered)} / {len(df)} images "
          f"({dropped} dropped as too blurry/corrupt)")
    return filtered


IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]

train_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ToTensor(),
    transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
])

eval_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
])


class RetinaDataset(Dataset):
    def __init__(self, df: pd.DataFrame, img_dir: str, transform=None):
        self.df = df.reset_index(drop=True)
        self.img_dir = img_dir
        self.transform = transform
        self.has_group = "group" in self.df.columns

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        img_path = os.path.join(self.img_dir, row["id_code"])
        img = Image.open(img_path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        label = int(row["diagnosis"])
        group = int(row["group"]) if self.has_group else -1
        return img, label, group


def get_weighted_sampler(df: pd.DataFrame) -> WeightedRandomSampler:
    """Class-imbalance handling: sample rare classes more often."""
    class_counts = df["diagnosis"].value_counts().to_dict()
    weights = df["diagnosis"].apply(lambda c: 1.0 / class_counts[c]).values
    weights = torch.DoubleTensor(weights)
    return WeightedRandomSampler(weights, num_samples=len(weights), replacement=True)
