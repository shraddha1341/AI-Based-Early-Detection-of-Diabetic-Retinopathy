"""
model.py
--------
A deliberately SIMPLE convolutional neural network, trained from scratch.

Note on approach: transfer learning (e.g. a pretrained ResNet18) is
usually the better real-world choice for a small medical-imaging dataset
like this, since it needs far less data. If your environment can reach
the internet to download ImageNet-pretrained weights
(torchvision.models.resnet18(weights=...)), that's a straightforward
swap-in upgrade -- see the commented-out version at the bottom of this
file. Here we use a small custom CNN instead so the whole pipeline runs
with zero external downloads.

Architecture: 4 conv blocks (conv -> batchnorm -> relu -> maxpool),
increasing channels, then a small fully-connected head with dropout to
fight overfitting on our small dataset. Kept intentionally shallow.
"""

import torch.nn as nn


class SimpleDRNet(nn.Module):
    def __init__(self, num_classes: int = 5):
        super().__init__()
        self.features = nn.Sequential(
            self._conv_block(3, 32),     # 224 -> 112
            self._conv_block(32, 64),    # 112 -> 56
            self._conv_block(64, 128),   # 56 -> 28
            self._conv_block(128, 256),  # 28 -> 14
        )
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Dropout(0.4),
            nn.Linear(256, 64),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes),
        )

    @staticmethod
    def _conv_block(in_ch, out_ch):
        return nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x


def build_model(num_classes: int = 5, freeze_backbone: bool = False) -> nn.Module:
    """freeze_backbone is unused here (kept so train.py's call signature
    doesn't need to change) -- this whole small network is trained end-to-end."""
    return SimpleDRNet(num_classes=num_classes)


# ---------------------------------------------------------------------------
# OPTIONAL UPGRADE (needs internet access to download ImageNet weights):
#
# from torchvision import models
# from torchvision.models import ResNet18_Weights
#
# def build_model(num_classes: int = 5, freeze_backbone: bool = True):
#     model = models.resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
#     if freeze_backbone:
#         for param in model.parameters():
#             param.requires_grad = False
#     model.fc = nn.Linear(model.fc.in_features, num_classes)
#     return model
# ---------------------------------------------------------------------------
