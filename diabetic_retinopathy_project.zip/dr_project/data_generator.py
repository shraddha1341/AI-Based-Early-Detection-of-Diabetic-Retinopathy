"""
data_generator.py
------------------
Creates a small SYNTHETIC retinal-fundus-like image dataset so the whole
pipeline can be run end-to-end right now, without needing to download the
real APTOS 2019 Blindness Detection dataset from Kaggle.

Each synthetic image is a circular "fundus" (retina photo) with:
  - a reddish-orange background (like a real retina photo)
  - a bright "optic disc" circle
  - blood-vessel-like branching lines
  - class-dependent lesion spots (more spots / more severe = higher DR grade)
  - random blur / darkening applied to SOME images to simulate poor image
    quality (this is used later to demonstrate the "image quality" handling)
  - a random synthetic "demographic group" (0 or 1) attached to each image,
    standing in for a real attribute like age-group or sex, so we can later
    check the model doesn't perform very differently across groups

Class imbalance is baked in on purpose (most images = "No DR"), because
that mirrors the real APTOS dataset and is one of the things the
assignment explicitly asks you to address.

TO USE REAL DATA INSTEAD:
Download the APTOS 2019 Blindness Detection dataset from Kaggle
(https://www.kaggle.com/c/aptos2019-blindness-detection), and place the
images + a train.csv (columns: id_code, diagnosis) under
  data/train/<image files>
  data/train.csv
Then skip this script entirely — dataset.py already knows how to read that
layout (see USE_REAL_DATA flag in dataset.py).
"""

import os
import csv
import random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

random.seed(42)
np.random.seed(42)

# 5 standard DR severity classes
CLASS_NAMES = ["No_DR", "Mild", "Moderate", "Severe", "Proliferative_DR"]

# Deliberately imbalanced counts -> mirrors real-world screening data,
# where most patients screened do NOT have advanced disease.
CLASS_COUNTS = {
    0: 220,  # No DR
    1: 70,   # Mild
    2: 60,   # Moderate
    3: 25,   # Severe
    4: 15,   # Proliferative DR
}

IMG_SIZE = 224
OUT_DIR = os.path.join(os.path.dirname(__file__), "data", "train")


def make_fundus_image(severity: int, group: int) -> Image.Image:
    img = Image.new("RGB", (IMG_SIZE, IMG_SIZE), (10, 10, 10))
    draw = ImageDraw.Draw(img)

    # Retina base circle (reddish-orange, like real fundus photos)
    base_color = (random.randint(140, 180), random.randint(50, 80), random.randint(30, 50))
    margin = 10
    draw.ellipse([margin, margin, IMG_SIZE - margin, IMG_SIZE - margin], fill=base_color)

    # Optic disc (bright circle, slightly off-center)
    disc_x = IMG_SIZE // 2 + random.randint(-40, 40)
    disc_y = IMG_SIZE // 2 + random.randint(-40, 40)
    disc_r = 18
    draw.ellipse([disc_x - disc_r, disc_y - disc_r, disc_x + disc_r, disc_y + disc_r],
                 fill=(230, 200, 150))

    # Blood vessels (branching lines from optic disc)
    for _ in range(8):
        angle = random.uniform(0, 2 * np.pi)
        length = random.randint(60, 100)
        x2 = disc_x + int(length * np.cos(angle))
        y2 = disc_y + int(length * np.sin(angle))
        draw.line([disc_x, disc_y, x2, y2], fill=(100, 30, 30), width=2)

    # Lesion spots (microaneurysms / hemorrhages) -- count scales with severity.
    # This is the actual visual signal the model has to learn to associate with DR grade.
    n_lesions = {0: 0, 1: random.randint(2, 4), 2: random.randint(5, 9),
                 3: random.randint(10, 16), 4: random.randint(17, 25)}[severity]
    for _ in range(n_lesions):
        lx = random.randint(margin + 20, IMG_SIZE - margin - 20)
        ly = random.randint(margin + 20, IMG_SIZE - margin - 20)
        lr = random.randint(2, 5) if severity < 3 else random.randint(3, 8)
        lesion_color = (60, 10, 10) if random.random() < 0.5 else (200, 180, 60)
        draw.ellipse([lx - lr, ly - lr, lx + lr, ly + lr], fill=lesion_color)

    # Subtle style difference by synthetic "demographic group" (e.g. imaging device /
    # population difference) -- small brightness shift, kept subtle on purpose.
    if group == 1:
        arr = np.array(img).astype(np.int16)
        arr = np.clip(arr + 8, 0, 255).astype(np.uint8)
        img = Image.fromarray(arr)

    return img


def maybe_degrade_quality(img: Image.Image) -> Image.Image:
    """Randomly simulate poor-quality captures: blur or under/over exposure."""
    r = random.random()
    if r < 0.12:
        img = img.filter(ImageFilter.GaussianBlur(radius=random.uniform(2.5, 5)))
    elif r < 0.20:
        arr = np.array(img).astype(np.int16)
        arr = np.clip(arr * random.uniform(0.4, 0.6), 0, 255).astype(np.uint8)
        img = Image.fromarray(arr)
    elif r < 0.26:
        arr = np.array(img).astype(np.int16)
        arr = np.clip(arr * random.uniform(1.5, 1.8), 0, 255).astype(np.uint8)
        img = Image.fromarray(arr)
    return img


def generate(out_dir: str = OUT_DIR):
    os.makedirs(out_dir, exist_ok=True)
    rows = [("id_code", "diagnosis", "group")]
    idx = 0
    for cls, count in CLASS_COUNTS.items():
        for _ in range(count):
            group = random.randint(0, 1)
            img = make_fundus_image(cls, group)
            img = maybe_degrade_quality(img)
            fname = f"img_{idx:05d}.png"
            img.save(os.path.join(out_dir, fname))
            rows.append((fname, cls, group))
            idx += 1

    csv_path = os.path.join(os.path.dirname(out_dir), "train.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(rows)

    print(f"Generated {idx} synthetic retinal images in: {out_dir}")
    print(f"Labels CSV written to: {csv_path}")
    print("Class distribution:", CLASS_COUNTS)


if __name__ == "__main__":
    generate()
