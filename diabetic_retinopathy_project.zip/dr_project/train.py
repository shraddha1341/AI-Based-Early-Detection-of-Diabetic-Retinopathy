"""
train.py
--------
The main script. Run this one file and it does everything end-to-end:

  1. Load labels + filter out low-quality (blurry) images   [image quality]
  2. Split into train/validation sets
  3. Build a class-balanced sampler so rare DR grades aren't ignored   [class imbalance]
  4. Fine-tune a pretrained ResNet18 on the data
  5. Evaluate: accuracy, confusion matrix, per-class recall
     (recall matters most here -- missing a real DR case, i.e. a false
     negative, is the costly mistake in a screening tool)
  6. Break down recall by the synthetic demographic "group" attribute
     to check the model isn't much worse for one group   [fairness]
  7. Generate Grad-CAM heatmaps for a few validation images   [explainability]

Everything is saved into outputs/:
  - dr_model.pt              trained model weights
  - confusion_matrix.png
  - training_curve.png
  - gradcam_examples.png
  - metrics_report.txt       plain-text summary of everything above

Usage:
    python train.py
"""

import os
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report, recall_score
import matplotlib.pyplot as plt
from PIL import Image

from dataset import (RetinaDataset, load_and_filter_labels, get_weighted_sampler,
                      train_transform, eval_transform, CLASS_NAMES, IMG_DIR)
from model import build_model
from gradcam import GradCAM, overlay_heatmap

OUT_DIR = os.path.join(os.path.dirname(__file__), "outputs")
os.makedirs(OUT_DIR, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
EPOCHS = 12
BATCH_SIZE = 16
LR = 5e-4
SEED = 42

torch.manual_seed(SEED)
np.random.seed(SEED)


def main():
    print(f"Using device: {DEVICE}\n")

    # ---- 1. Load + quality-filter data -------------------------------
    df = load_and_filter_labels()

    # ---- 2. Train / validation split (stratified so rare classes appear in both) --
    train_df, val_df = train_test_split(
        df, test_size=0.2, random_state=SEED, stratify=df["diagnosis"]
    )
    print(f"Train size: {len(train_df)}  |  Val size: {len(val_df)}\n")

    train_ds = RetinaDataset(train_df, IMG_DIR, transform=train_transform)
    val_ds = RetinaDataset(val_df, IMG_DIR, transform=eval_transform)

    # ---- 3. Class-imbalance handling: weighted sampler ----------------
    sampler = get_weighted_sampler(train_df)
    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, sampler=sampler)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False)

    # ---- 4. Model -------------------------------------------------------
    model = build_model(num_classes=len(CLASS_NAMES), freeze_backbone=True).to(DEVICE)

    # NOTE: the weighted sampler above already handles class imbalance by
    # changing how often each class is *seen* during training. Also adding
    # class weights to the loss on top of that double-compensates (the model
    # ends up over-predicting rare classes and ignoring "No DR" entirely) --
    # so we use plain CrossEntropyLoss here and let the sampler do the work.
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=1e-4)

    # ---- 5. Train ---------------------------------------------------------
    train_losses, val_accs = [], []
    for epoch in range(1, EPOCHS + 1):
        model.train()
        running_loss = 0.0
        for imgs, labels, _ in train_loader:
            imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * imgs.size(0)
        epoch_loss = running_loss / len(train_ds)
        train_losses.append(epoch_loss)

        val_acc, _, _, _ = evaluate(model, val_loader)
        val_accs.append(val_acc)
        print(f"Epoch {epoch}/{EPOCHS} | train_loss={epoch_loss:.4f} | val_acc={val_acc:.3f}")

    # ---- 6. Final evaluation: confusion matrix + per-class recall ---------
    val_acc, all_preds, all_labels, all_groups = evaluate(model, val_loader)
    cm = confusion_matrix(all_labels, all_preds, labels=list(range(len(CLASS_NAMES))))
    report = classification_report(all_labels, all_preds, target_names=CLASS_NAMES,
                                    zero_division=0)

    print("\nFinal validation accuracy:", round(val_acc, 3))
    print("\nClassification report:\n", report)

    plot_confusion_matrix(cm, CLASS_NAMES, os.path.join(OUT_DIR, "confusion_matrix.png"))
    plot_training_curve(train_losses, val_accs, os.path.join(OUT_DIR, "training_curve.png"))

    # ---- 7. Fairness check across synthetic demographic groups ------------
    fairness_report = fairness_by_group(all_labels, all_preds, all_groups)

    # ---- 8. Explainability: Grad-CAM on a few validation examples ---------
    gradcam_path = run_gradcam_examples(model, val_df)

    # ---- 9. Save model + full text report ----------------------------------
    torch.save(model.state_dict(), os.path.join(OUT_DIR, "dr_model.pt"))

    with open(os.path.join(OUT_DIR, "metrics_report.txt"), "w") as f:
        f.write("DIABETIC RETINOPATHY SCREENING MODEL - METRICS REPORT\n")
        f.write("=" * 55 + "\n\n")
        f.write(f"Final validation accuracy: {val_acc:.3f}\n\n")
        f.write("Classification report (per-class precision/recall/F1):\n")
        f.write(report + "\n\n")
        f.write("Confusion matrix (rows=true, cols=predicted):\n")
        f.write(np.array2string(cm) + "\n\n")
        f.write("Fairness check (recall by demographic group):\n")
        f.write(fairness_report + "\n")

    print(f"\nAll outputs saved to: {OUT_DIR}")
    print(" - dr_model.pt (trained weights)")
    print(" - confusion_matrix.png")
    print(" - training_curve.png")
    print(" - gradcam_examples.png")
    print(" - metrics_report.txt")


def evaluate(model, loader):
    model.eval()
    all_preds, all_labels, all_groups = [], [], []
    correct, total = 0, 0
    with torch.no_grad():
        for imgs, labels, groups in loader:
            imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
            outputs = model(imgs)
            preds = outputs.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)
            all_preds.extend(preds.cpu().numpy().tolist())
            all_labels.extend(labels.cpu().numpy().tolist())
            all_groups.extend(groups.numpy().tolist())
    acc = correct / total
    return acc, all_preds, all_labels, all_groups


def fairness_by_group(labels, preds, groups) -> str:
    labels, preds, groups = np.array(labels), np.array(preds), np.array(groups)
    lines = []
    for g in sorted(set(groups.tolist())):
        mask = groups == g
        if mask.sum() == 0:
            continue
        # "DR present" = any class > 0. This is the clinically important
        # recall: are we missing real disease cases for this group?
        y_true_bin = (labels[mask] > 0).astype(int)
        y_pred_bin = (preds[mask] > 0).astype(int)
        rec = recall_score(y_true_bin, y_pred_bin, zero_division=0)
        lines.append(f"  Group {g}: n={mask.sum():3d} | DR-detection recall = {rec:.3f}")
    text = "\n".join(lines)
    print("\nFairness check (recall for detecting any DR, by group):")
    print(text)
    gap_note = ("\n  (A large gap between groups here would mean the model is\n"
                "   missing real DR cases more often for one group than another\n"
                "   -- worth investigating further with more balanced data.)")
    return text + gap_note


def plot_confusion_matrix(cm, class_names, save_path):
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=45, ha="right")
    ax.set_yticklabels(class_names)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title("Confusion Matrix - DR Severity Classification")
    for i in range(len(class_names)):
        for j in range(len(class_names)):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im)
    fig.tight_layout()
    fig.savefig(save_path, dpi=130)
    plt.close(fig)


def plot_training_curve(train_losses, val_accs, save_path):
    fig, ax1 = plt.subplots(figsize=(6, 4))
    ax1.plot(train_losses, color="tab:red", label="train loss")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Train loss", color="tab:red")
    ax2 = ax1.twinx()
    ax2.plot(val_accs, color="tab:blue", label="val accuracy")
    ax2.set_ylabel("Validation accuracy", color="tab:blue")
    fig.suptitle("Training Progress")
    fig.tight_layout()
    fig.savefig(save_path, dpi=130)
    plt.close(fig)


def run_gradcam_examples(model, val_df, n_examples: int = 4):
    target_layer = model.features[-1]  # last conv block of SimpleDRNet
    cam_tool = GradCAM(model, target_layer)

    sample_rows = val_df.sample(n=min(n_examples, len(val_df)), random_state=SEED)
    fig, axes = plt.subplots(1, len(sample_rows), figsize=(4 * len(sample_rows), 4))
    if len(sample_rows) == 1:
        axes = [axes]

    for ax, (_, row) in zip(axes, sample_rows.iterrows()):
        img_path = os.path.join(IMG_DIR, row["id_code"])
        orig = Image.open(img_path).convert("RGB").resize((224, 224))
        tensor = eval_transform(orig).unsqueeze(0).to(DEVICE)
        cam, pred_class = cam_tool.generate(tensor)
        blended = overlay_heatmap(orig, cam)
        ax.imshow(blended)
        ax.set_title(f"True: {CLASS_NAMES[row['diagnosis']]}\nPred: {CLASS_NAMES[pred_class]}",
                     fontsize=9)
        ax.axis("off")

    fig.suptitle("Grad-CAM: where the model is looking")
    fig.tight_layout()
    save_path = os.path.join(OUT_DIR, "gradcam_examples.png")
    fig.savefig(save_path, dpi=130)
    plt.close(fig)
    return save_path


if __name__ == "__main__":
    main()
