# AI-Based Early Detection of Diabetic Retinopathy — Case Study 15

A simple, working, end-to-end pipeline for classifying retinal fundus
images into 5 diabetic retinopathy (DR) severity grades, built to
directly address every requirement in the case study: **class
imbalance**, **image quality**, **explainability**, and **fairness
across demographic groups**.

## How to run it

```bash
pip install torch torchvision numpy pandas scikit-learn scikit-image pillow matplotlib

python data_generator.py   # creates the dataset (see note below)
python train.py            # trains the model + produces all results
```

Everything (trained model, plots, metrics report) is written to `outputs/`.

## About the dataset

The case study calls for retinal images from diabetic patients, and the
standard public dataset for this exact task is **APTOS 2019 Blindness
Detection** on Kaggle (~3,600 labeled fundus photos, 5 severity classes).

This project could not download that dataset directly (no Kaggle access
in this environment), so `data_generator.py` **synthesizes a small
retina-like image dataset** instead — same 5-class structure, same
built-in class imbalance, same idea of image-quality issues and a
demographic attribute — so the *entire pipeline actually runs and
produces real results* right now.

**To use the real APTOS dataset instead** (recommended for your final
submission if you have time):
1. Download it from https://www.kaggle.com/c/aptos2019-blindness-detection
2. Put the images in `data/train/` and the label file as `data/train.csv`
   with columns `id_code, diagnosis` (add a `group` column too if you
   want to test fairness across a real attribute, e.g. patient age
   bucket — optional, the code skips this check gracefully if absent)
3. In `dataset.py`, set `USE_REAL_DATA = True` (this only matters as a
   marker — the loading code already works with this exact layout)
4. Run `python train.py` again — no other code changes needed

## Project structure

| File | What it does |
|---|---|
| `data_generator.py` | Builds the synthetic retina image dataset (or stands in for it) |
| `dataset.py` | Loads images/labels, **filters blurry images** (image quality), builds a **class-balanced sampler** (class imbalance) |
| `model.py` | A small CNN (4 conv blocks) trained from scratch — kept simple on purpose |
| `gradcam.py` | Grad-CAM implementation — produces heatmaps showing what the model focused on (explainability) |
| `train.py` | Main script: trains the model, evaluates it, checks fairness across groups, generates Grad-CAM examples, saves everything |

## How each requirement is addressed

**1. Class imbalance**
The synthetic (and real APTOS) data has far more "No DR" images than
"Severe"/"Proliferative DR" ones. `dataset.get_weighted_sampler()`
oversamples rare classes during training so the model doesn't just learn
to always predict "No DR". (Note: we deliberately do *not* also add
class weights to the loss on top of the sampler — doing both
over-corrects and makes the model ignore the majority class instead.)

**2. Image quality**
`dataset.load_and_filter_labels()` runs a Laplacian-variance blur check
on every image before training and drops ones too blurry to be
diagnostically useful — mirroring how a real screening tool would flag
"please recapture this image" rather than guessing on a bad photo.

**3. Explainability**
`gradcam.py` + `train.run_gradcam_examples()` generate heatmaps showing
which regions of each retina image most influenced the model's
prediction (`outputs/gradcam_examples.png`). In a real clinical setting,
this lets a doctor sanity-check that the model is actually looking at
lesions/vessels, not some irrelevant part of the image.

**4. Fairness across demographic groups**
`train.fairness_by_group()` reports the DR-detection recall (i.e. "of
patients who really have DR, how many did we correctly flag") separately
for each demographic group, so you can see if the model is missing real
disease more often in one group than another — the costliest kind of
error in a screening tool.

## Results from the last run (synthetic data)

- **Overall validation accuracy: 72.1%**
- Recall is highest for No_DR and Proliferative_DR; Mild/Moderate are
  the hardest to tell apart (expected — they're the most visually
  similar in the disease progression)
- DR-detection recall was 0.82 and 0.85 across the two synthetic
  demographic groups — no large fairness gap on this synthetic data,
  but this is exactly the kind of check that could reveal a gap on a
  real, less-balanced dataset

Full numbers are in `outputs/metrics_report.txt`.

## Honest limitations (worth mentioning in your write-up)

- The dataset here is synthetic and small — real DR features (soft
  exudates, microaneurysms, hemorrhages) are visually far more subtle
  and varied than what's simulated here
- Trained from scratch rather than via transfer learning (a pretrained
  ResNet would very likely do better, especially on a small dataset) —
  this was a workaround for not having internet access to pretrained
  weights in this environment, not a recommendation
- "Group" here is a synthetic stand-in; a real fairness analysis needs a
  real demographic attribute with appropriate ethical handling of that
  data
