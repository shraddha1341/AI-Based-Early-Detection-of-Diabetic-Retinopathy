"""
gradcam.py
----------
A minimal Grad-CAM implementation -- the standard, simple way to make a
CNN's prediction explainable: it produces a heatmap over the input image
showing which regions the model "looked at" most to make its decision.

This directly addresses the "explainability" requirement: instead of the
model just outputting "Severe DR" with no justification, a doctor can see
the heatmap and check whether the model is actually focusing on lesions /
blood vessels (a sensible reason) versus some irrelevant corner of the
image (a red flag that the model learned the wrong thing).
"""

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image


class GradCAM:
    def __init__(self, model: torch.nn.Module, target_layer: torch.nn.Module):
        self.model = model
        self.target_layer = target_layer
        self.activations = None
        self.gradients = None
        target_layer.register_forward_hook(self._save_activation)
        target_layer.register_full_backward_hook(self._save_gradient)

    def _save_activation(self, module, inp, out):
        self.activations = out.detach()

    def _save_gradient(self, module, grad_in, grad_out):
        self.gradients = grad_out[0].detach()

    def generate(self, input_tensor: torch.Tensor, class_idx: int = None):
        self.model.eval()
        output = self.model(input_tensor)
        if class_idx is None:
            class_idx = int(output.argmax(dim=1).item())

        self.model.zero_grad()
        score = output[0, class_idx]
        score.backward()

        # Global-average-pool the gradients -> importance weight per channel
        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1, keepdim=True)
        cam = F.relu(cam)
        cam = F.interpolate(cam, size=input_tensor.shape[2:], mode="bilinear", align_corners=False)
        cam = cam.squeeze().cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam, class_idx


def overlay_heatmap(orig_img: Image.Image, cam: np.ndarray, alpha: float = 0.45) -> Image.Image:
    """Blend the Grad-CAM heatmap on top of the original image for display."""
    import matplotlib.cm as cm

    heatmap = (cm.jet(cam)[:, :, :3] * 255).astype(np.uint8)
    heatmap_img = Image.fromarray(heatmap).resize(orig_img.size)
    blended = Image.blend(orig_img.convert("RGB"), heatmap_img, alpha=alpha)
    return blended
